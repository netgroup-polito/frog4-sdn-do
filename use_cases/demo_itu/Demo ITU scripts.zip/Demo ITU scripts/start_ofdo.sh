#!/bin/bash
cd ~/git-repositories/frog4-openflow-do
./start.sh -d config/config.ini

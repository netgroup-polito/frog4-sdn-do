#!/bin/bash
sudo ifconfig eno1 0
sudo ifconfig eno1 10.0.1.2/24

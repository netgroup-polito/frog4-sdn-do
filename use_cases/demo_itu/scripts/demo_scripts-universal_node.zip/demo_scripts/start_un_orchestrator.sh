#!/bin/bash
cd ~/git-repositories/un-orchestrator/orchestrator/
sudo ./node-orchestrator --d config/demo_onos_config.ini

#!/bin/bash
cd ~/git-repositories/frog4-openflow-do
python3 -m scripts.clean_all

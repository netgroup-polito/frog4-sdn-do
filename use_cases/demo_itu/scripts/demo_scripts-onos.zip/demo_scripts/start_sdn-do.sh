#!/bin/bash
cd ~/git-repositories/frog4-sdn-do
./start.sh -d config/config.ini

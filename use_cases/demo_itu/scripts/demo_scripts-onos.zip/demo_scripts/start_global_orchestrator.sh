#!/bin/bash
cd ~/git-repositories/frog4-orchestrator
./start_orchestrator.sh --d config/onos-demo-config.ini

#!/bin/bash
cd ~/git-repositories/onos-applications/ovsdb-rest/
onos-app 192.168.123.1 reinstall target/ovsdb-rest-1.9.0-SNAPSHOT.oar

#!/bin/bash
cd ~/git-repositories/onos-applications/apps-capabilities/
onos-app 192.168.123.1 reinstall target/apps-capabilities-1.0-SNAPSHOT.oar

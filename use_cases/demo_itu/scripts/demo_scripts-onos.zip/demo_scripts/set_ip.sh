#!/bin/bash
sudo ifconfig eth1 0
sudo ifconfig eth1 10.0.1.1/24

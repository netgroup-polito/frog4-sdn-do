DELETE FROM domain;

DELETE FROM domain_information;

DELETE FROM domain_gre;

DELETE FROM domain_neighbor;

DELETE FROM domain_vlan;

DELETE FROM domain_token;

DELETE FROM session;

DELETE FROM graph;

DELETE FROM functional_capability;

DELETE FROM function_specification;


#!/bin/bash
cd ~/UN\ GUI/fg-gui1
./start.sh &
cd ~/UN\ GUI/fg-guiONOS
./start.sh &

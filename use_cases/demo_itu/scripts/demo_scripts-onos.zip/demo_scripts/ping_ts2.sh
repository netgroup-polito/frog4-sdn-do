ping 130.192.225.241 | perl -nle 'print scalar(localtime), " ", $_'

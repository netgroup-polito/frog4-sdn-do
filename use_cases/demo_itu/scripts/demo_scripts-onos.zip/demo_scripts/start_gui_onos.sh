#!/bin/bash
cd ~/UN\ GUI/fg-guiONOS
./start.sh
